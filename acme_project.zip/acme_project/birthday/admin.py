from django.contrib import admin

from .models import Birthday


@admin.register(Birthday)
class LocationAdmin(admin.ModelAdmin):
    """Интерфейс для местоположения."""

    list_display = (
        "first_name",
        "last_name",
        "birthday",
        "image"
    )